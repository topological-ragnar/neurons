%% gen_text.m - generate text by running network
%
% network and text parameters are defined from esn.m and text2vec.m

fprintf('\n########\n');
n_init = 100; % Uses one more than this

x = zeros(n_input,1);
y = zeros(n_neuron,1);

sz=sqrt(n_neuron);

% prime the network
start_idx = randi(length(text_inds) - (n_init+1));
for i = start_idx:(start_idx+n_init-1)
    x(x ~= 0) = 0;
    x(text_inds(i)) = 1;
    fprintf('%c', alphabet(text_inds(i)));
    y = tanh(W*y + Q*x);
end

x(x ~= 0) = 0;
x(text_inds(start_idx + n_init)) = 1;
fprintf('%c', alphabet(text_inds(start_idx + n_init)));
    
fprintf('>>>>>');

T=100;
Y=zeros(n_neuron,T);
for i = 1:T
    y = tanh(W*y + Q*x);
    [max_val x_out] = max(R*y + b);
    fprintf('%c', alphabet(x_out));
    x(x ~= 0) = 0;
    x(x_out) = 1;
    Y(:,i)=y;
end

fprintf('\n########\n');
